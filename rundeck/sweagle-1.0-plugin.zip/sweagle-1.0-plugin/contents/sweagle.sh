#!/bin/bash

# variables set by plugin properties

: ${RD_CONFIG_URL:?"url plugin property not sepecified"}
: ${RD_CONFIG_FILTER:?"filter plugin property not specified"}
: ${RD_CONFIG_TOKEN:?"token plugin property not specified"}
: ${RD_CONFIG_ENVIRONMENT:?"environment plugin property not specified"}
: ${RD_CONFIG_MDS:?"mds plugin property not specified"}
: ${RD_CONFIG_EXPORTER:?"exporter plugin property not specified"}

hosts=$(curl -s -X POST "${RD_CONFIG_URL}/api/v1/tenant/metadata-parser/parse?mds=${RD_CONFIG_MDS}&args=${RD_CONFIG_FILTER}&parser=${RD_CONFIG_EXPORTER}&format=json" -H "Authorization: bearer ${RD_CONFIG_TOKEN}")

if [[ $? -ne 0 ]];then
  exit $?
fi

echo $hosts

exit $?
